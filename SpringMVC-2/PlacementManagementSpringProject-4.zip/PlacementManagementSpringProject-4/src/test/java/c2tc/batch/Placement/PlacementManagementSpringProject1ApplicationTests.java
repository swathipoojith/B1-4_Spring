package c2tc.batch.Placement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementManagementSpringProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
